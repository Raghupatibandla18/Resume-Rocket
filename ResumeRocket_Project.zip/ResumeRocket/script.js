const $ = id => document.getElementById(id);
const formFields = ["name","title","email","phone","location","links","summary","skills","jobDescription"];
const lists = {education: $("educationList"), experience: $("experienceList"), project: $("projectList")};

function addEntry(type, values = {}) {
  const configs = {
    education: [["degree","Degree / course"],["school","College / university"],["year","Year"],["details","Grade / details"]],
    experience: [["role","Job title"],["company","Company"],["period","Dates"],["details","Responsibilities / achievements"]],
    project: [["projectName","Project name"],["tech","Technologies"],["details","Project description"]]
  };
  const entry = document.createElement("div");
  entry.className = "entry";
  entry.dataset.type = type;
  const fields = document.createElement("div");
  fields.className = "fields two";
  configs[type].forEach(([key, label]) => {
    const wrap = document.createElement("label");
    wrap.textContent = label;
    const input = key === "details" ? document.createElement("textarea") : document.createElement("input");
    if (key === "details") input.rows = 2;
    input.dataset.key = key;
    input.placeholder = label;
    input.value = values[key] || "";
    input.addEventListener("input", updatePreview);
    wrap.appendChild(input);
    fields.appendChild(wrap);
  });
  const remove = document.createElement("button");
  remove.type = "button"; remove.className = "remove-btn"; remove.textContent = "Remove";
  remove.addEventListener("click", () => { entry.remove(); updatePreview(); });
  entry.append(fields, remove);
  lists[type].appendChild(entry);
  updatePreview();
}

function getEntries(type) {
  return [...lists[type].querySelectorAll(".entry")].map(entry => {
    const data = {};
    entry.querySelectorAll("[data-key]").forEach(input => data[input.dataset.key] = input.value.trim());
    return data;
  }).filter(item => Object.values(item).some(Boolean));
}
function esc(value) {
  return String(value || "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
function itemHTML(title, meta, details) {
  if (![title,meta,details].some(Boolean)) return "";
  return `<div class="resume-item">${title ? `<strong>${esc(title)}</strong>` : ""}${meta ? `<p class="meta">${esc(meta)}</p>` : ""}${details ? `<p class="description">${esc(details)}</p>` : ""}</div>`;
}
function updatePreview() {
  const val = id => $(id).value.trim();
  $("pName").textContent = val("name") || "Your Name";
  $("pTitle").textContent = val("title") || "Your Professional Title";
  $("pContact").textContent = [val("email"),val("phone"),val("location"),val("links")].filter(Boolean).join("  ·  ") || "Email · Phone · Location · LinkedIn";
  $("pSummary").textContent = val("summary") || "Your professional summary will appear here.";
  $("pSkills").textContent = val("skills") || "Your skills will appear here.";
  const exp = getEntries("experience");
  $("pExperience").innerHTML = exp.length ? exp.map(x=>itemHTML(x.role, [x.company,x.period].filter(Boolean).join(" | "),x.details)).join("") : '<p class="placeholder">Your work experience will appear here.</p>';
  const edu = getEntries("education");
  $("pEducation").innerHTML = edu.length ? edu.map(x=>itemHTML(x.degree,x.school ? `${x.school}${x.year ? " | "+x.year : ""}` : x.year,x.details)).join("") : '<p class="placeholder">Your education will appear here.</p>';
  const proj = getEntries("project");
  $("pProjects").innerHTML = proj.length ? proj.map(x=>itemHTML(x.projectName,x.tech,x.details)).join("") : '<p class="placeholder">Your projects will appear here.</p>';
  $("resumePreview").className = `resume ${$("template").value}`;
  calculateScore(false);
}
function calculateScore(showMessage = true) {
  const val = id => $(id).value.trim();
  let score = 0;
  const checks = [
    [!!val("name") && !!val("email") && !!val("phone"),15],
    [!!val("summary"),10],
    [getEntries("education").length > 0,15],
    [getEntries("experience").length > 0,15],
    [getEntries("project").length > 0,10],
    [val("skills").split(",").filter(x=>x.trim()).length >= 3,15],
    [!!val("title"),10],
    [!!val("location") && !!val("links"),5],
    [((val("summary")+" "+val("skills")+" "+getEntries("experience").map(x=>x.details).join(" ")).match(/\d+%?|\d+\+/g)||[]).length > 0,5]
  ];
  checks.forEach(([ok,points])=>{if(ok)score+=points;});
  $("score").textContent = score+"%";
  $("scoreBar").style.width = score+"%";
  $("scoreLabel").textContent = score>=80 ? "Strong profile — keep refining" : score>=50 ? "Good start — add missing details" : "Complete more sections to improve";
  if(showMessage) toast("ATS score evaluated: "+score+"%");
  return score;
}
function toast(message){const t=$("toast");t.textContent=message;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2200);}
function saveDraft(){
  const data={};
  formFields.forEach(id=>data[id]=$(id).value);
  data.template=$("template").value;
  Object.keys(lists).forEach(type=>data[type]=getEntries(type));
  localStorage.setItem("resumerocket-draft",JSON.stringify(data));
  toast("Your resume draft has been saved on this device.");
}
function loadDraft(){
  const raw=localStorage.getItem("resumerocket-draft");
  if(!raw)return;
  try{
    const data=JSON.parse(raw);
    formFields.forEach(id=>{if(data[id]!==undefined)$(id).value=data[id];});
    $("template").value=data.template||"modern";
    Object.keys(lists).forEach(type=>{
      lists[type].innerHTML="";
      (data[type]||[]).forEach(item=>addEntry(type,item));
    });
  }catch(e){console.warn("Could not load saved draft",e);}
}
function matchKeywords(){
  const job=$("jobDescription").value.toLowerCase();
  const resume=[ $("title").value,$("summary").value,$("skills").value,
    ...getEntries("experience").flatMap(x=>Object.values(x)),
    ...getEntries("project").flatMap(x=>Object.values(x))
  ].join(" ").toLowerCase();
  if(!job){$("keywordResults").textContent="Paste a job description first.";return;}
  const stop=new Set(["the","and","for","with","you","our","are","will","that","this","from","have","has","your","job","work","team","years","year","who","all","any","able","about","into","their","they","use","using","experience","skills","role"]);
  const words=job.match(/[a-z][a-z+#.]{2,}/g)||[];
  const keywords=[...new Set(words)].filter(w=>!stop.has(w)).filter(w=>w.length>2).slice(0,35);
  const found=keywords.filter(w=>resume.includes(w));
  const missing=keywords.filter(w=>!resume.includes(w));
  $("keywordResults").innerHTML=`<p><strong>${found.length}</strong> matching · <strong>${missing.length}</strong> suggested keywords</p>`+
    found.map(w=>`<span class="tag">${esc(w)}</span>`).join("")+
    missing.map(w=>`<span class="tag missing">${esc(w)}</span>`).join("");
}
formFields.forEach(id=>$(id).addEventListener("input",updatePreview));
$("template").addEventListener("change",updatePreview);
$("addEducation").addEventListener("click",()=>addEntry("education"));
$("addExperience").addEventListener("click",()=>addEntry("experience"));
$("addProject").addEventListener("click",()=>addEntry("project"));
$("saveBtn").addEventListener("click",saveDraft);
$("evaluateBtn").addEventListener("click",()=>calculateScore(true));
$("matchBtn").addEventListener("click",matchKeywords);
$("downloadBtn").addEventListener("click",()=>{
  const element=$("resumePreview");
  if(window.html2pdf){
    html2pdf().set({margin:0,filename:"ResumeRocket-Resume.pdf",image:{type:"jpeg",quality:0.98},html2canvas:{scale:2,useCORS:true},jsPDF:{unit:"mm",format:"a4",orientation:"portrait"},pagebreak:{mode:["css","legacy"]}}).from(element).save();
  }else{
    window.print();
  }
});
loadDraft();
if(!getEntries("education").length)addEntry("education");
if(!getEntries("experience").length)addEntry("experience");
if(!getEntries("project").length)addEntry("project");
updatePreview();
