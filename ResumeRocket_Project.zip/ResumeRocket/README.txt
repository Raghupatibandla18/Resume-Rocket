# ResumeRocket – ATS Resume Builder

## Run the project
1. Download and extract `ResumeRocket.zip`.
2. Open the `ResumeRocket` folder in Visual Studio Code.
3. Open `index.html` in a browser, or use the VS Code Live Server extension.
4. Enter your details. The preview updates while you type.
5. Choose a template and click **Evaluate ATS score**.
6. Click **Download PDF** to export your resume.

## Files
- `index.html` – page structure and form fields
- `style.css` – layout, responsive design and resume templates
- `script.js` – live preview, ATS scoring, keyword matching, local saving and PDF export

## Notes
- Resume drafts are saved in your browser's LocalStorage on the same device/browser.
- PDF export uses html2pdf.js from a CDN, so an internet connection is needed for that library. If it is unavailable, the browser print dialog is used instead.
- The ATS score is a simple educational heuristic, not a real employer ATS score. It checks contact completeness, standard sections, skills and measurable achievements.
- Keyword matching is a basic word matcher. It does not understand synonyms or context.
